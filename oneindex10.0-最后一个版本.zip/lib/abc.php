<?php
namespace jane;
	class abc{
    
    
    
    static function index(){
        
        //exit;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}